create definer = root@localhost event e_test_insert on schedule
    every '3' SECOND
        starts '2020-11-27 11:06:20'
    enable
    do
    insert into users(username,`password`) values('qqq','123');

